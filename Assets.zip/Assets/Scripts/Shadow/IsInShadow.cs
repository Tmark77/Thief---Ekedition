﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IsInShadow : MonoBehaviour {

    public Transform player;
    public Transform head;
    public Transform chest;
    public Transform foot;

    bool hH; //head is in 
    bool hC; //chest is in shadow
    bool hF; //foot is in shadow
    
    int i; //index
    int fullDark; //teljes árnyék
    public int range;

    public Transform[] lights;
    public bool fullHide;

	// Use this for initialization
	void Start () {
        hH = false;
        hC = false;
        hF = false;
    }
	
	// Update is called once per frame
	void Update () {
        for (i = 0; i < lights.Length; i++)
        {
            if(Hide(i) == true)
            {
                fullDark++;
            }
        }
        if(fullDark == lights.Length)
        {
            fullHide = true;
        }
        else
        {
            fullHide = false;
        }
        fullDark = 0;
        i = 0;
    }

    bool Hide(int index)
    {
        Debug.DrawLine(lights[index].transform.position, head.position, Color.red);
        Debug.DrawLine(lights[index].transform.position, chest.position, Color.blue);
        Debug.DrawLine(lights[index].transform.position, foot.position, Color.green);

        RaycastHit hit;
        float distance = Vector3.Distance(lights[i].transform.position, player.position);
        hH = Sensor(head, hH, index);
        hC = Sensor(head, hC, index);
        hF = Sensor(head, hF, index);

        if ((hH && hC || hH && hF || hC && hF) || distance > range)
        {
            return true;
        }
        else return false;
    }

    bool Sensor(Transform obj,bool sensor, int i)
    {
        RaycastHit hit;
        if (Physics.Linecast(lights[i].transform.position, obj.position, out hit))
        {
            Debug.Log(hit.transform.name);
            if (hit.transform.name != "Player")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else return false;
    }
}
