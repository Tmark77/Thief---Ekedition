﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IsInShadow : MonoBehaviour {

    public Transform head;
    public Transform chest;
    public Transform foot;

    bool hH; //head is in 
    bool hC; //chest is in shadow
    bool hF; //foot is in shadow

    public bool isHiding;

	// Use this for initialization
	void Start () {
        isHiding = false;
        hH = false;
        hC = false;
        hF = false;
    }
	
	// Update is called once per frame
	void Update () {
        Hide();
    }

    void Hide()
    {
        Debug.DrawLine(transform.position, head.position, Color.red);
        Debug.DrawLine(transform.position, chest.position, Color.blue);
        Debug.DrawLine(transform.position, foot.position, Color.green);

        RaycastHit hit;

        if (Physics.Linecast(transform.position, head.position, out hit))
        {
            Debug.Log(hit.transform.name);
            if (hit.transform.name != "Player")
            {
                hH = true;
            }
            else
            {
                hH = false;
            }
        }

        if (Physics.Linecast(transform.position, chest.position, out hit))
        {
            Debug.Log(hit.transform.name);
            if (hit.transform.name != "Player")
            {
                hC = true;
            }
            else
            {
                hC = false;
            }
        }

        if (Physics.Linecast(transform.position, foot.position, out hit))
        {
            Debug.Log(hit.transform.name);
            if (hit.transform.name != "Player")
            {
                hF = true;
            }
            else
            {
                hF = false;
            }
        }

        if (hH && hC || hH && hF || hC && hF)
        {
            isHiding = true;
        }
        else isHiding = false;
    }
}
